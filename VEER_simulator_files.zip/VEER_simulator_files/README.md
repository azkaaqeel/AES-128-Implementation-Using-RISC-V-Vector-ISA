# IBA_PROJECT

The command "make all" will run the encryption file.
to run the decryption file, make changes in the "MakeFile" present in this directory. Replace the filename with the decryption file's name.
